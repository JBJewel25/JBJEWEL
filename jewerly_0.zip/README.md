# JEWELLERY_SHOP_MANAGEMENT
5th Sem Mini Project of DBMS ON Jewellery Shop Management

Online Jewellery Shop is basically used to build an application  program which help people to find and buy latest design of jewellery with different categories like Gold Silver, Diamond . It is useful in the way that it makes an easier way to  buy products online.Today most of the jewellery shop is useful for shopping site. The admin have lots of paper work and they are using desktop, spread sheet like MS Excel application to manage data in soft copy about user record. In this proposed jewellery System it will run in server and user can handle whole the registration activities.


#Software requirements

Operating system : windows

Atom : as text editor for source code.

Webserver :Xampp-apache server
