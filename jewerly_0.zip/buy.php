<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" media="screen" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.5/css/bootstrap.min.css">

	<title>THANKS FOR ORDERING !!!</title>
	<!--  -->

	<style>

          *{
             	margin:0px;
             	padding:0px;
             }

             body{
             	background-image: url();
             	background-size: 100% 110%;
             	width: 100%;
             	height: 100vh;
                 background-color:gray;
               }
               .text h1{
             	font-size:100px;
             	font-family: 'Montserrat', sans-serif;
             	font-weight: 100px;
             	margin:14px 0px;

             }

             .text h2{
             	font-size: 20px;
             	font-family: 'Open Sans', sans-serif;
             }


	</style>

</head>

<body>
    <h1>THANKS FOR SHOPPING!!!</h1><br><br>
    <h2> Check your product details on your EMAIL ID</h2>
	<div class="container">

	</div>

	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.5/js/bootstrap.min.js"></script>

	<script>
	</script>

</body>

</html>
